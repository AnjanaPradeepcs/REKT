import 'package:flutter/material.dart';

class AppColor {
  static const Color background = Color(0xFF1E1E1E);
  static const Color black = Color(0xFF000000);
  static const Color lightWhite = Color(0xFFD9D9D9);
  static const Color yellow = Color(0xFFF9E27B);
  static const Color green = Color(0xFF0DD05B);
  static const Color red = Color(0xFFFF5555);
  static const Color redDark = Color(0xFFAF0808);
}
