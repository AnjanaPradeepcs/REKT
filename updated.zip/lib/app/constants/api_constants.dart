// ignore_for_file: constant_identifier_names

class APIConstants {
  static const String BASE_URL =
      "http://ec2-43-204-176-117.ap-south-1.compute.amazonaws.com";
  static const String LOGIN = "/portal/login/";
  static const String TOKEN_REFRESH = "/portal/token-refresh/";
  static const String ADD_OWNER = "/portal/add-owner/";
  static const String DELETE_OWNER = "/portal/delete-owner/";
  static const String TOGGLE_OWNER_STATUS = "/portal/toggle-owner-status";
  static const String GET_DASHBOARD_ANALYTICS =
      "/portal/get-dashboard-analytics/";
  static const String GET_EVENT_ANALYTICS = "/portal/get-events-metrics/";
}
