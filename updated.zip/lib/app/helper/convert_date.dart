import 'package:intl/intl.dart';

class Helper {
  static convertDate(String date) {
    return DateFormat('dd MMM yyyy').format(DateTime.parse(date));
  }
}
