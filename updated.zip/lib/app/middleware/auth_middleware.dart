import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../utils/flutter_toast.dart';
import '../../data/provider/preferences_manager.dart';

class AuthMiddleware extends GetMiddleware {
  @override
  int? get priority => 1;

  @override
  RouteSettings? redirect(String? route) {
    final PreferenceManager preferenceManager = Get.find<PreferenceManager>();
    if (!preferenceManager.isLogin) {
      AppToast.showErrorMessage('Please login first');
      return const RouteSettings(name: '/login');
    }
    return null;
  }
}
