import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../color.dart';

class AppToast {
  static void showErrorMessage(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.TOP_RIGHT,
      webBgColor: "linear-gradient(to right, #ff0000, #ff0000)",
      backgroundColor: AppColor.red,
      textColor: Colors.white,
      fontSize: 16.0,
    );
  }

  static void showSuccessMessage(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.TOP_RIGHT,
      timeInSecForIosWeb: 1,
      backgroundColor: AppColor.green,
      textColor: Colors.white,
      fontSize: 16.0,
    );
  }
}
