import 'package:get/get.dart';

class Responsive {
  static width(double px) {
    return px * (Get.width / 1728);
  }

  static height(double px) {
    return px * (Get.width / 1728);
  }
}
