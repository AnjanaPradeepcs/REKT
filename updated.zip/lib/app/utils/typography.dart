import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../color.dart';

final Map<String, TextStyle> _storedFonts = {};
final Map<String, FontWeight> _fontWeights = {
  "100": FontWeight.w100,
  "200": FontWeight.w200,
  "300": FontWeight.w300,
  "400": FontWeight.w400,
  "500": FontWeight.w500,
  "600": FontWeight.w600,
  "700": FontWeight.w700,
  "800": FontWeight.w800,
  "900": FontWeight.w900
};
final Map<String, Color> _fontColor = {
  "black": Colors.black,
  "white": Colors.white,
  "yellow": AppColor.yellow,
  "green": AppColor.green,
  "red": AppColor.red,
  "redDark": AppColor.redDark,
};

TextStyle fontStyle(String style) {
  final double scaleFactor = Get.textScaleFactor * .85;

  final String key = style + scaleFactor.toString();

  if (_storedFonts.containsKey(key)) {
    return _storedFonts[key]!;
  } else {
    final List<String> styleList = style.trim().split(":");
    late final Color color;
    if (styleList[0].contains("-")) {
      final List<String> colorList = styleList[0].split("-");
      final Color color0 = _fontColor[colorList[0]] ?? Colors.black;
      final double opacity = double.parse(colorList[1]);
      color = color0.withOpacity(opacity);
    } else {
      color = _fontColor[styleList[0]] ?? Colors.black;
    }
    final FontWeight fontWeight = _fontWeights[styleList[1]] ?? FontWeight.w400;
    final double fontSize = double.parse(styleList[2]);

    final TextStyle textStyle = TextStyle(
        fontFamily: "Monserrat",
        color: color,
        fontWeight: fontWeight,
        fontSize: fontSize * scaleFactor);
    _storedFonts[key] = textStyle;

    return textStyle;
  }
}
