class ClientModel {
  final String name;
  final String uniqueId;
  final String password;
  final int activeEvents;
  final double dailyAverage;
  final String status;

  ClientModel({
    required this.name,
    required this.uniqueId,
    required this.password,
    required this.activeEvents,
    required this.dailyAverage,
    required this.status,
  });
}
