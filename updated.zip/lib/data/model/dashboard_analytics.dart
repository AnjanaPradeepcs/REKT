class DashboardAnalytics {
  final double totalTransaction;
  final double todayTransaction;
  final int todayChangeInTransaction;
  final double yesterdayTransaction;
  final int yesterdayChangeInTransaction;

  DashboardAnalytics({
    required this.totalTransaction,
    required this.todayTransaction,
    required this.todayChangeInTransaction,
    required this.yesterdayTransaction,
    required this.yesterdayChangeInTransaction,
  });

  factory DashboardAnalytics.fromJson(Map<String, dynamic> json) {
    return DashboardAnalytics(
      totalTransaction: json['total_transactions'],
      todayTransaction: json['transaction_status_present']
          ['total_transactions'],
      todayChangeInTransaction: json['transaction_status_present']
          ['transaction_status'],
      yesterdayTransaction: json['transaction_status_previous']
          ['total_transactions'],
      yesterdayChangeInTransaction: json['transaction_status_previous']
          ['transaction_status'],
    );
  }
}
