class EventModel {
  final String title;
  final String id;
  final String imgUri;
  final String description;

  const EventModel({
    required this.id,
    required this.imgUri,
    required this.description,
    required this.title,
  });
}
