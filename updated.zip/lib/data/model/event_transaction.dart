import '../../app/helper/convert_date.dart';

class EventTransactionModel {
  String name;
  String ticketSold;
  String totalTransaction;
  String convinceFee;
  String eventDate;

  EventTransactionModel(
      {required this.name,
      required this.ticketSold,
      required this.totalTransaction,
      required this.convinceFee,
      required this.eventDate});

  factory EventTransactionModel.fromJson(Map<String, dynamic> json) {
    return EventTransactionModel(
        name: json['name'],
        ticketSold: json['total_tickets'].toString(),
        totalTransaction: json['total_transactions'] == null
            ? "0"
            : json['total_transactions'].toString(),
        convinceFee: json['total_convenience_fees'] == null
            ? "0"
            : json['total_convenience_fees'].toString(),
        // eventDate: json['date_time'].toString()
        eventDate: Helper.convertDate(json['date_time'].toString()));
  }
}
