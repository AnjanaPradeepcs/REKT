class UserModel {
  final String name;
  final String userID;
  final String firstName;
  final String? phone;

  UserModel({
    required this.name,
    required this.userID,
    required this.firstName,
    required this.phone,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      name: json['name'],
      userID: json['user_id'].toString(),
      firstName: json['first_name'],
      phone: json['phone'] == "Nil" ? null : json['phone'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'user_id': userID,
      'first_name': firstName,
      'phone': phone,
    };
  }
}
