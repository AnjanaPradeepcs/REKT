import 'dart:async';
import 'dart:convert';

import 'package:dartz/dartz.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'preferences_manager.dart';

import '../../app/constants/api_constants.dart';
import '../model/failure.dart';

class HttpProvider extends GetxService {
  Future<Either<Failure, Map<String, dynamic>>> get<T>(
    String url, {
    String? token,
  }) async {
    print(token);
    try {
      Map<String, String> headers = {
        'Content-Type': 'application/json',
      };
      if (token != null) {
        headers.addAll({'Authorization': 'Bearer $token'});
      }
      final response = await http.get(Uri.parse(url), headers: headers).timeout(
            const Duration(seconds: 10),
          );

      if (response.statusCode == 200) {
        return Right(json.decode(response.body)['response']);
      } else {
        if (await _checkAndRefreshToken(response.body)) {
          return get(url, token: Get.find<PreferenceManager>().token);
        } else {
          return Left(
              Failure(json.decode(response.body)['details']["message"]));
        }
      }
    } catch (e) {
      if (e is TimeoutException) {
        return Left(Failure("Timeout"));
      }

      return Left(Failure("Something went wrong"));
    }
  }

  Future<Either<Failure, Map<String, dynamic>>> post<T>(
    String url,
    Map<String, dynamic> body, {
    String? token,
  }) async {
    Map<String, String> headers = {
      'Content-Type': 'application/json',
    };
    if (token != null) {
      headers.addAll({'Authorization': 'Bearer $token'});
    }
    try {
      final response = await http
          .post(Uri.parse(url), body: json.encode(body), headers: headers)
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        return Right(json.decode(response.body)['response']);
      } else {
        return Left(Failure(json.decode(response.body)['details']["message"]));
      }
    } catch (e) {
      if (e is TimeoutException) {
        return Left(Failure("Timeout"));
      }
      return Left(Failure("Something went wrong"));
    }
  }

  Future<bool> _checkAndRefreshToken(String body) async {
    final preferenceManager = Get.find<PreferenceManager>();
    if (body.contains('token_not_valid')) {
      final response = await http.post(
        Uri.parse(APIConstants.BASE_URL + APIConstants.TOKEN_REFRESH),
        body: {
          'refresh': preferenceManager.refreshToken,
        },
      );
      if (response.statusCode == 200) {
        preferenceManager.token = json.decode(response.body)['access'];
        preferenceManager.refreshToken = json.decode(response.body)['refresh'];
        return true;
      } else {
        preferenceManager.logout();
        Get.offAllNamed('/login');
      }
    }
    return false;
  }
}
