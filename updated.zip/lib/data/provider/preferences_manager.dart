import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import '../model/user_model.dart';

class PreferenceManager extends GetxService {
  static final GetStorage _getStorage = GetStorage();

  UserModel get user => UserModel.fromJson(_getStorage.read('user'));
  set user(UserModel value) => _getStorage.write('user', value.toJson());

  String get token => _getStorage.read('token');
  set token(String value) => _getStorage.write('token', value);

  String get refreshToken => _getStorage.read('refreshToken');
  set refreshToken(String value) => _getStorage.write('refreshToken', value);

  String get username => _getStorage.read('username');
  set username(String value) => _getStorage.write('username', value);

  String get password => _getStorage.read('password');
  set password(String value) => _getStorage.write('password', value);

  bool get isLogin => _getStorage.read('isLogin') ?? false;
  set isLogin(bool value) => _getStorage.write('isLogin', value);

  void logout() {
    _getStorage.remove('user');
    _getStorage.remove('token');
    _getStorage.remove('refreshToken');
    _getStorage.remove('username');
    _getStorage.remove('password');
    _getStorage.remove('isLogin');
  }
}
