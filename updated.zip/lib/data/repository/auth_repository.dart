import 'package:get/get.dart';
import '../../app/utils/flutter_toast.dart';
import '../model/user_model.dart';
import '../provider/preferences_manager.dart';

import '../../app/constants/api_constants.dart';
import '../provider/http_provider.dart';

class AuthRepository {
  final HttpProvider _httpProvider = Get.find<HttpProvider>();
  final PreferenceManager _preferenceManager = Get.find<PreferenceManager>();

  Future<bool> login(String username, String password) async {
    final response = await _httpProvider.post(
      APIConstants.BASE_URL + APIConstants.LOGIN,
      {
        'username': username,
        'password': password,
      },
    );

    response.fold(
      (failure) {
        AppToast.showErrorMessage(failure.message);
      },
      (data) {
        _preferenceManager.user = UserModel.fromJson(data['user']);
        _preferenceManager.token = data['access'];
        _preferenceManager.refreshToken = data['refresh'];
        _preferenceManager.username = username;
        _preferenceManager.password = password;
        _preferenceManager.isLogin = true;
      },
    );

    return response.isRight();
  }

  void logout() {
    _preferenceManager.username = '';
    _preferenceManager.password = '';
    _preferenceManager.isLogin = false;
  }
}
