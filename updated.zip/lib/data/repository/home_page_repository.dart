import 'package:get/get.dart';
import '../../app/constants/api_constants.dart';
import '../model/dashboard_analytics.dart';
import '../provider/http_provider.dart';

import '../../app/utils/flutter_toast.dart';
import '../model/event_transaction.dart';
import '../provider/preferences_manager.dart';

class HomePageRepository {
  final HttpProvider _httpProvider = Get.find<HttpProvider>();
  final PreferenceManager _preferenceManager = Get.find<PreferenceManager>();

  //get dashboard analytics metrics
  Future<DashboardAnalytics> getDashboardMetrics() async {
    final response = await _httpProvider.get(
      APIConstants.BASE_URL + APIConstants.GET_DASHBOARD_ANALYTICS,
      token: _preferenceManager.token,
    );

    return response.fold(
      (failure) {
        AppToast.showErrorMessage(failure.message);
        return DashboardAnalytics(
          todayChangeInTransaction: 0,
          todayTransaction: 0,
          totalTransaction: 0,
          yesterdayChangeInTransaction: 0,
          yesterdayTransaction: 0,
        );
      },
      (data) {
        return DashboardAnalytics.fromJson(data);
      },
    );
  }

  //get events metrics
  Future<List<EventTransactionModel>> getEventMetrics() async {
    final response = await _httpProvider.get(
      APIConstants.BASE_URL + APIConstants.GET_EVENT_ANALYTICS,
      token: _preferenceManager.token,
    );

    return response.fold(
      (failure) {
        AppToast.showErrorMessage(failure.message);
        return [];
      },
      (data) {
        return (data["events_metrics"] as List)
            .map((e) => EventTransactionModel.fromJson(e))
            .toList();
      },
    );
  }
}
