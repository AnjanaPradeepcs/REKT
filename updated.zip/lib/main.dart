import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'view/splash/splash_screen_view.dart';
import 'package:url_strategy/url_strategy.dart';

import 'app/middleware/auth_middleware.dart';
import 'data/provider/http_provider.dart';
import 'data/provider/preferences_manager.dart';
import 'view/home/home_screen_view.dart';
import 'view/login/login_screen_view.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await GetStorage.init();
  setPathUrlStrategy();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'REKT',
      debugShowCheckedModeBanner: false,
      onInit: () {
        Get.put(PreferenceManager());
        Get.put(HttpProvider());
      },
      scrollBehavior: const ScrollBehavior().copyWith(
        dragDevices: {
          PointerDeviceKind.touch,
          PointerDeviceKind.mouse,
        },
        scrollbars: false,
      ),
      getPages: [
        GetPage(name: '/', page: () => const SplashScreenView()),
        GetPage(name: '/login', page: () => const LoginScreenView()),
        GetPage(
            name: '/home',
            page: () => const HomeScreenView(),
            middlewares: [AuthMiddleware()]),
      ],
    );
  }
}
