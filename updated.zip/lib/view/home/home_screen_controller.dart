import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'pages/event_page/event_details_page_view.dart';
import 'pages/event_page/event_page_view.dart';
import 'pages/ticket_page/ticket_page_view.dart';

import '../../data/provider/preferences_manager.dart';
import 'pages/client_page/clients_page_view.dart';
import 'pages/home_page/home_page_view.dart';

enum AppPage { home, events, eventsDetails, eventGuests, clients, tickets }

class HomeScreenController extends GetxController {
  final PreferenceManager _preferenceManager = Get.find<PreferenceManager>();
  final RxString username = "Admin".obs;
  final Rx<Widget> currentPage = Rx<Widget>(const HomePageView());
  final Rx<AppPage> selectedPage = Rx<AppPage>(AppPage.home);
  late final Map<AppPage, Function> _navMap;

  @override
  void onInit() {
    _navMap = {
      AppPage.home: (_) {
        selectedPage.value = AppPage.home;
        return const HomePageView();
      },
      AppPage.events: (_) {
        selectedPage.value = AppPage.events;
        return EventPageView();
      },
      AppPage.eventsDetails: (dynamic arguments) {
        selectedPage.value = AppPage.events;
        return EventDetailsPageView(event: arguments);
      },
      AppPage.eventGuests: (dynamic arguments) {
        selectedPage.value = AppPage.events;
        return EventDetailsPageView(event: arguments);
      },
      AppPage.clients: (dynamic arguments) {
        selectedPage.value = AppPage.clients;
        return const ClientsPageView();
      },
      AppPage.tickets: (dynamic arguments) {
        selectedPage.value = AppPage.tickets;
        return TicketPageView();
      },
    };
    username.value = _preferenceManager.username;
    super.onInit();
  }

  void navigateTo(AppPage page, {dynamic arguments}) {
    currentPage.value = _navMap[page]!(arguments);
  }
}
