import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../app/color.dart';
import 'home_screen_controller.dart';

import 'widgets/home_header.dart';
import 'widgets/nav_drawer.dart';

class HomeScreenView extends StatefulWidget {
  const HomeScreenView({super.key});

  @override
  State<HomeScreenView> createState() => _HomeScreenViewState();
}

class _HomeScreenViewState extends State<HomeScreenView> {
  final List<Map<String, AppPage>> _navItems = [
    {"HOME": AppPage.home},
    {"EVENTS": AppPage.events},
    {"CLIENTS": AppPage.clients},
    {"TICKETS": AppPage.tickets}
  ];
  final HomeScreenController _controller = Get.put(HomeScreenController());
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AppColor.background,
        body: SizedBox(
          height: MediaQuery.of(context).size.height,
          child: Row(
            children: [
              Expanded(
                flex: 25,
                //Drawer
                child: NavDrawer(
                  navItems: _navItems,
                ),
              ),
              Expanded(
                flex: 119,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AspectRatio(aspectRatio: 10.1647, child: HomeHeader()),
                    Expanded(
                      child: Obx(() => _controller.currentPage.value),
                    )
                  ],
                ),
              ),
            ],
          ),
        ));
  }
}
