import 'package:get/get.dart';

import '../../../../data/model/client_model.dart';

class ClientsPageController extends GetxController {
  RxList<ClientModel> clients = <ClientModel>[].obs;

  @override
  void onInit() {
    clients.addAll([
      ClientModel(
        name: "FlyHigh Kochi",
        uniqueId: "25",
        password: "12345678",
        activeEvents: 5,
        dailyAverage: 5000,
        status: "Suspended",
      ),
      ClientModel(
        name: 'PetroPark',
        uniqueId: "26",
        password: "1234567890",
        activeEvents: 2,
        dailyAverage: 2000,
        status: "Active",
      ),
      ClientModel(
        name: 'Avenue Kochi',
        uniqueId: "27",
        password: "1234567890",
        activeEvents: 2,
        dailyAverage: 1000,
        status: "Active",
      ),
      ClientModel(
        name: 'EcoPark Kochi',
        uniqueId: "28",
        password: "1234567890",
        activeEvents: 3,
        dailyAverage: 4000,
        status: "Active",
      ),
    ]);
    super.onInit();
  }

  //user function
  void addClient(ClientModel client) {
    clients.add(client);
  }
}
