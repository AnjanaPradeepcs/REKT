import 'package:flutter/material.dart';

import 'package:get/get.dart';
import '../../../../app/utils/typography.dart';
import 'clients_page_controller.dart';
import 'show_client_add_dialog.dart';

import '../../../../app/color.dart';
import '../../../../app/utils/responsive.dart';

class ClientsPageView extends StatefulWidget {
  const ClientsPageView({super.key});

  @override
  State<ClientsPageView> createState() => _ClientsPageViewState();
}

class _ClientsPageViewState extends State<ClientsPageView> {
  final ClientsPageController controller = Get.put(ClientsPageController());

  RxBool isDeleteMode = false.obs;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: Responsive.width(64),
          vertical: Responsive.height(57),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Clients List", style: fontStyle("white:600:22")),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {
                        showClientAddDialog();
                      },
                      child: Text(
                        "ADD",
                        style: fontStyle("green:600:22"),
                      ),
                    ),
                    SizedBox(width: Responsive.width(77)),
                    InkWell(
                      onTap: () {
                        isDeleteMode.value = !isDeleteMode.value;
                      },
                      child: Text(
                        "DELETE",
                        style: fontStyle("redDark:600:22"),
                      ),
                    ),
                  ],
                )
              ],
            ),
            SizedBox(
              height: Responsive.height(41),
            ),
            Obx(() {
              return Table(
                children: [
                  TableRow(
                    children: [
                      Padding(
                        padding: EdgeInsets.only(
                            bottom: Responsive.height(38), left: 24),
                        child: Center(
                          child: Text(
                            'Name',
                            style: fontStyle("white:400:22"),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(bottom: Responsive.height(38)),
                        child: Center(
                          child: Text('Unique ID',
                              style: fontStyle("white:400:22")),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(bottom: Responsive.height(38)),
                        child: Center(
                          child: Text('Password',
                              style: fontStyle("white:400:22")),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(bottom: Responsive.height(38)),
                        child: Center(
                          child: Text('Active Events',
                              style: fontStyle("white:400:22")),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(bottom: Responsive.height(38)),
                        child: Center(
                          child: Text('Daily Average',
                              style: fontStyle("white:400:22")),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(bottom: Responsive.height(38)),
                        child: const Text(''),
                      ),
                    ],
                  ),
                  for (var i = 0; i < controller.clients.length; i++)
                    TableRow(
                      children: [
                        Container(
                          margin: const EdgeInsets.only(bottom: 9),
                          padding: EdgeInsets.symmetric(
                              horizontal: Responsive.width(10),
                              vertical: Responsive.height(24)),
                          color: AppColor.lightWhite.withOpacity(0.2),
                          child: Center(
                            child: Text(
                              controller.clients[i].name.toUpperCase(),
                              style: fontStyle("white:600:21"),
                            ),
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.only(bottom: 9),
                          padding: EdgeInsets.symmetric(
                              vertical: Responsive.height(24)),
                          color: AppColor.lightWhite.withOpacity(0.2),
                          child: Center(
                            child: Text(
                              controller.clients[i].uniqueId,
                              style: fontStyle("white:600:21"),
                            ),
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.only(bottom: 9),
                          padding: EdgeInsets.symmetric(
                              vertical: Responsive.height(24)),
                          color: AppColor.lightWhite.withOpacity(0.2),
                          child: Center(
                            child: Text(
                              controller.clients[i].password,
                              style: fontStyle("white:600:21"),
                            ),
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.only(bottom: 9),
                          padding: EdgeInsets.symmetric(
                              vertical: Responsive.height(24)),
                          color: AppColor.lightWhite.withOpacity(0.2),
                          child: Center(
                            child: Text(
                              controller.clients[i].activeEvents.toString(),
                              style: fontStyle("white:600:21"),
                            ),
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.only(bottom: 9),
                          padding: EdgeInsets.symmetric(
                              vertical: Responsive.height(24)),
                          color: AppColor.lightWhite.withOpacity(0.2),
                          child: Center(
                            child: Text(
                              "\$${controller.clients[i].dailyAverage}",
                              style: fontStyle("white:600:21"),
                            ),
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.only(bottom: 9),
                          padding: EdgeInsets.symmetric(
                              vertical: Responsive.height(24)),
                          color: AppColor.lightWhite.withOpacity(0.2),
                          child: Center(
                            child: Text(
                              controller.clients[i].status.toUpperCase(),
                              style: fontStyle("yellow:600:21"),
                            ),
                          ),
                        ),
                      ],
                    ),
                ],
              );
            }),
          ],
        ),
      ),
    );
  }
}
