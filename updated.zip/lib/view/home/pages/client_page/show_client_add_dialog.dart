import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../app/utils/typography.dart';
import '../../../../data/model/client_model.dart';

import 'clients_page_controller.dart';

void showClientAddDialog() {
  Widget buildTextFormField({
    required String label,
    required TextEditingController controller,
    TextInputType keyboardType = TextInputType.text,
    bool obscureText = false,
  }) {
    return TextFormField(
      obscureText: obscureText,
      style: fontStyle("white:600:16"),
      controller: controller,
      keyboardType: keyboardType,
      validator: (String? value) {
        if (value == null || value.isEmpty) {
          return 'Please enter $label';
        } else if (label == 'Active Events' || label == 'Daily Average') {
          if (int.tryParse(value) == null) {
            return 'Please enter a valid number';
          }
        }
        return null;
      },
      decoration: InputDecoration(
        hintStyle: fontStyle("white-0.6:400:16"),
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white),
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.white),
          borderRadius: BorderRadius.circular(10),
        ),
        border: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.white),
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController uniqueIdController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController activeEventsController = TextEditingController();
  final TextEditingController dailyAverageController = TextEditingController();
  final List<String> status = ['Active', 'Suspended'];
  final RxString selectedStatus = 'Active'.obs;
  Get.dialog(
    Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      backgroundColor: Colors.grey[800],
      child: Container(
        padding: const EdgeInsets.all(40),
        width: 500,
        child: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              buildTextFormField(
                label: 'Name',
                controller: nameController,
              ),
              const SizedBox(height: 20),
              buildTextFormField(
                label: 'Unique ID',
                controller: uniqueIdController,
              ),
              const SizedBox(height: 20),
              buildTextFormField(
                label: 'Password',
                controller: passwordController,
                obscureText: true,
              ),
              const SizedBox(height: 20),
              buildTextFormField(
                label: 'Active Events',
                controller: activeEventsController,
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 20),
              buildTextFormField(
                label: 'Daily Average',
                controller: dailyAverageController,
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 20),
              Obx(
                () => Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    color: Colors.grey[800],
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.white),
                  ),
                  child: DropdownButton(
                    style: fontStyle("white:600:16"),
                    isExpanded: true,
                    underline: const SizedBox(),
                    dropdownColor: Colors.grey[800],
                    borderRadius: BorderRadius.circular(10),
                    value: selectedStatus.value,
                    items: status.map((String value) {
                      return DropdownMenuItem(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                    onChanged: (String? value) {
                      selectedStatus.value = value!;
                    },
                  ),
                ),
              ),
              InkWell(
                splashColor: Colors.transparent,
                onTap: () {
                  if (formKey.currentState!.validate()) {
                    final ClientModel client = ClientModel(
                      name: nameController.text,
                      uniqueId: uniqueIdController.text,
                      password: passwordController.text,
                      activeEvents: int.parse(activeEventsController.text),
                      dailyAverage: double.parse(dailyAverageController.text),
                      status: selectedStatus.value,
                    );
                    Get.find<ClientsPageController>().addClient(client);
                    Get.back();
                  }
                },
                child: Container(
                  margin: const EdgeInsets.only(top: 20),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 40,
                    vertical: 10,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.green,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    'ADD',
                    style: fontStyle("white:600:16"),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    ),
  );
}
