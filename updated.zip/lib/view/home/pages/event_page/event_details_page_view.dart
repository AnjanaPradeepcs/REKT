import 'package:flutter/material.dart';

import 'package:get/get.dart';
import '../../../../data/model/event_model.dart';
import '../../home_screen_controller.dart';
import 'event_page_controller.dart';

import '../../../../app/color.dart';
import '../../../../app/utils/responsive.dart';
import '../../../../app/utils/typography.dart';

class EventDetailsPageView extends StatelessWidget {
  const EventDetailsPageView({super.key, required this.event});
  final EventModel event;
  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColor.background,
      padding: EdgeInsets.symmetric(
        horizontal: Responsive.width(67),
        vertical: Responsive.height(44),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                event.title,
                style: fontStyle("white:600:22"),
              ),
              const SizedBox(height: 52),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(
                      event.description,
                      style: fontStyle("white:300:19"),
                    ),
                  ),
                  SizedBox(
                    width: Responsive.width(100),
                  ),
                  Container(
                    width: Responsive.width(288),
                    height: Responsive.height(227),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: AppColor.lightWhite,
                      image: DecorationImage(
                        image: NetworkImage(event.imgUri),
                        fit: BoxFit.cover,
                        isAntiAlias: true,
                      ),
                      backgroundBlendMode: BlendMode.darken,
                    ),
                  ),
                ],
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              InkWell(
                child: Text(
                  'VIEW GUEST LIST',
                  style: fontStyle("white:600:22"),
                ),
              ),
              SizedBox(width: Responsive.width(166)),
              InkWell(
                onTap: () {
                  Get.find<HomeScreenController>().navigateTo(AppPage.events);
                  Get.find<EventPageController>().deleteEvent(event);
                },
                child: Text(
                  'DELETE THIS EVENT',
                  style: fontStyle("redDark:600:22"),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}
