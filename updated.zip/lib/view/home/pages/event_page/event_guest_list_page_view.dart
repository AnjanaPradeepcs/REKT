import 'package:flutter/material.dart';

class EventGustListPageView extends StatelessWidget {
  const EventGustListPageView({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
