import 'package:get/get.dart';

import '../../../../data/model/event_model.dart';
import '../../home_screen_controller.dart';

class EventPageController extends GetxController {
  final HomeScreenController homeScreenController = Get.find();

  final RxList<EventModel> hotEvents = <EventModel>[].obs;
  final RxList<EventModel> recommendedEvents = <EventModel>[].obs;
  final RxList<EventModel> allEvents = <EventModel>[].obs;

  //For Testing Purpose
  @override
  void onInit() {
    hotEvents.add(
      const EventModel(
        id: "1",
        title: "Event One",
        imgUri: "https://picsum.photos/300/300?random=1",
        description: """
Gather your friends for a night of "AFROPOP" late night brunch every Wednesday featuring “DJ LATY”, "DJ PHYZ", "DJ JEVANNI LETFORD", “DJ SHONI” and “MC MONEY PLUS” with the latest Afrobeats.
 
From 9 p.m. till 1 a.m.
Live entertainment + DJs
 
- Open daily: 8 p.m. - 4 a.m.
- Shisha Available
- Dress Code: Smart Casual / Elegant
- Location : 50th Floor, voco Hotel, Sheikh Zayed Road
""",
      ),
    );
    hotEvents.add(
      const EventModel(
        id: "2",
        title: "Event Two",
        imgUri: "https://picsum.photos/300/300?random=2",
        description: """
Gather your friends for a night of "AFROPOP" late night brunch every Wednesday featuring “DJ LATY”, "DJ PHYZ", "DJ JEVANNI LETFORD", “DJ SHONI” and “MC MONEY PLUS” with the latest Afrobeats.
 
From 9 p.m. till 1 a.m.
Live entertainment + DJs
 
- Open daily: 8 p.m. - 4 a.m.
- Shisha Available
- Dress Code: Smart Casual / Elegant
- Location : 50th Floor, voco Hotel, Sheikh Zayed Road
""",
      ),
    );
    hotEvents.add(
      const EventModel(
        id: "3",
        title: "Event Three",
        imgUri: "https://picsum.photos/300/300?random=3",
        description: """
Gather your friends for a night of "AFROPOP" late night brunch every Wednesday featuring “DJ LATY”, "DJ PHYZ", "DJ JEVANNI LETFORD", “DJ SHONI” and “MC MONEY PLUS” with the latest Afrobeats.
 
From 9 p.m. till 1 a.m.
Live entertainment + DJs
 
- Open daily: 8 p.m. - 4 a.m.
- Shisha Available
- Dress Code: Smart Casual / Elegant
- Location : 50th Floor, voco Hotel, Sheikh Zayed Road
""",
      ),
    );
    hotEvents.add(
      const EventModel(
        id: "4",
        title: "Event Four",
        imgUri: "https://picsum.photos/300/300?random=4",
        description: """
Gather your friends for a night of "AFROPOP" late night brunch every Wednesday featuring “DJ LATY”, "DJ PHYZ", "DJ JEVANNI LETFORD", “DJ SHONI” and “MC MONEY PLUS” with the latest Afrobeats.
 
From 9 p.m. till 1 a.m.
Live entertainment + DJs
 
- Open daily: 8 p.m. - 4 a.m.
- Shisha Available
- Dress Code: Smart Casual / Elegant
- Location : 50th Floor, voco Hotel, Sheikh Zayed Road
""",
      ),
    );
    hotEvents.add(
      const EventModel(
        id: "5",
        title: "Event Five",
        imgUri: "https://picsum.photos/300/300?random=5",
        description: """
Gather your friends for a night of "AFROPOP" late night brunch every Wednesday featuring “DJ LATY”, "DJ PHYZ", "DJ JEVANNI LETFORD", “DJ SHONI” and “MC MONEY PLUS” with the latest Afrobeats.
 
From 9 p.m. till 1 a.m.
Live entertainment + DJs
 
- Open daily: 8 p.m. - 4 a.m.
- Shisha Available
- Dress Code: Smart Casual / Elegant
- Location : 50th Floor, voco Hotel, Sheikh Zayed Road
""",
      ),
    );
    hotEvents.add(
      const EventModel(
        id: "6",
        title: "Event Six",
        imgUri: "https://picsum.photos/300/300?random=6",
        description: """
Gather your friends for a night of "AFROPOP" late night brunch every Wednesday featuring “DJ LATY”, "DJ PHYZ", "DJ JEVANNI LETFORD", “DJ SHONI” and “MC MONEY PLUS” with the latest Afrobeats.
 
From 9 p.m. till 1 a.m.
Live entertainment + DJs
 
- Open daily: 8 p.m. - 4 a.m.
- Shisha Available
- Dress Code: Smart Casual / Elegant
- Location : 50th Floor, voco Hotel, Sheikh Zayed Road
""",
      ),
    );
    hotEvents.add(
      const EventModel(
        id: "7",
        title: "Event Seven",
        imgUri: "https://picsum.photos/300/300?random=7",
        description: """
Gather your friends for a night of "AFROPOP" late night brunch every Wednesday featuring “DJ LATY”, "DJ PHYZ", "DJ JEVANNI LETFORD", “DJ SHONI” and “MC MONEY PLUS” with the latest Afrobeats.
 
From 9 p.m. till 1 a.m.
Live entertainment + DJs
 
- Open daily: 8 p.m. - 4 a.m.
- Shisha Available
- Dress Code: Smart Casual / Elegant
- Location : 50th Floor, voco Hotel, Sheikh Zayed Road
""",
      ),
    );
    hotEvents.add(
      const EventModel(
        id: "8",
        title: "Event Eight",
        imgUri: "https://picsum.photos/300/300?random=8",
        description: """
Gather your friends for a night of "AFROPOP" late night brunch every Wednesday featuring “DJ LATY”, "DJ PHYZ", "DJ JEVANNI LETFORD", “DJ SHONI” and “MC MONEY PLUS” with the latest Afrobeats.
 
From 9 p.m. till 1 a.m.
Live entertainment + DJs
 
- Open daily: 8 p.m. - 4 a.m.
- Shisha Available
- Dress Code: Smart Casual / Elegant
- Location : 50th Floor, voco Hotel, Sheikh Zayed Road
""",
      ),
    );

    recommendedEvents.addAll(hotEvents);
    allEvents.addAll(hotEvents);

    super.onInit();
  }

  void goToEventDetailPage(EventModel event) {
    homeScreenController.navigateTo(
      AppPage.eventsDetails,
      arguments: event,
    );
  }

  void deleteEvent(EventModel event) {
    hotEvents.remove(event);
    recommendedEvents.remove(event);
    allEvents.remove(event);
  }
}
