import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../app/utils/responsive.dart';
import '../../../../app/utils/typography.dart';

import '../../../../app/color.dart';
import 'event_page_controller.dart';

class EventPageView extends StatelessWidget {
  EventPageView({super.key});
  final EventPageController controller = Get.put(EventPageController());
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        padding: const EdgeInsets.symmetric(
          vertical: 44,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: Responsive.width(64)),
              child: Text(
                'WHAT’S HOT',
                style: fontStyle("white:600:22"),
              ),
            ),
            const SizedBox(height: 19),
            SizedBox(
              height: Responsive.height(165),
              child: Obx(
                () => ListView.builder(
                  padding: EdgeInsets.only(left: Responsive.width(64)),
                  scrollDirection: Axis.horizontal,
                  itemCount: controller.hotEvents.length,
                  itemBuilder: (BuildContext context, int index) {
                    return AspectRatio(
                      aspectRatio: 1.7586,
                      child: InkWell(
                        onTap: () {
                          controller
                              .goToEventDetailPage(controller.hotEvents[index]);
                        },
                        child: Container(
                          margin: EdgeInsets.only(right: Responsive.width(42)),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: AppColor.lightWhite,
                              image: DecorationImage(
                                image: NetworkImage(
                                    controller.hotEvents[index].imgUri),
                                fit: BoxFit.cover,
                                isAntiAlias: true,
                              ),
                              backgroundBlendMode: BlendMode.darken),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
            const SizedBox(
              height: 59,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: Responsive.width(64)),
              child: Text(
                "Recommended this week",
                style: fontStyle("white:600:22"),
              ),
            ),
            const SizedBox(
              height: 19,
            ),
            SizedBox(
              height: Responsive.height(165),
              child: Obx(
                () => ListView.builder(
                  padding: EdgeInsets.only(left: Responsive.width(64)),
                  scrollDirection: Axis.horizontal,
                  itemCount: controller.recommendedEvents.length,
                  itemBuilder: (BuildContext context, int index) {
                    return AspectRatio(
                      aspectRatio: 1.7586,
                      child: InkWell(
                        onTap: () {
                          controller.goToEventDetailPage(
                              controller.recommendedEvents[index]);
                        },
                        child: Container(
                          margin: EdgeInsets.only(right: Responsive.width(42)),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: AppColor.lightWhite,
                              image: DecorationImage(
                                image: NetworkImage(
                                    controller.recommendedEvents[index].imgUri),
                                fit: BoxFit.cover,
                                isAntiAlias: true,
                              ),
                              backgroundBlendMode: BlendMode.darken),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
            const SizedBox(
              height: 58,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: Responsive.width(64)),
              child: Text(
                "All Events",
                style: fontStyle("white:600:22"),
              ),
            ),
            const SizedBox(
              height: 19,
            ),
            GridView.builder(
              padding: EdgeInsets.only(
                left: Responsive.width(64),
                right: Responsive.width(64),
                bottom: Responsive.height(64),
              ),
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: controller.allEvents.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                crossAxisSpacing: Responsive.width(48),
                mainAxisSpacing: Responsive.width(61),
                childAspectRatio: 1.0044,
              ),
              itemBuilder: (BuildContext context, int index) {
                return InkWell(
                  onTap: () {
                    controller.goToEventDetailPage(controller.allEvents[index]);
                  },
                  child: Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: AppColor.lightWhite,
                        image: DecorationImage(
                          image:
                              NetworkImage(controller.allEvents[index].imgUri),
                          fit: BoxFit.cover,
                          isAntiAlias: true,
                        ),
                        backgroundBlendMode: BlendMode.darken),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
