import 'package:get/get.dart';
import '../../../../data/model/event_transaction.dart';

import '../../../../data/repository/home_page_repository.dart';

class HomePageController extends GetxController {
  final HomePageRepository _homePageRepository = HomePageRepository();
  final RxDouble totalPrice = 0.0.obs;
  final RxDouble todayPrice = 0.0.obs;
  final RxDouble yesterdayPrice = 0.0.obs;
  RxString username = "Admin".obs;
  final RxInt todayChangeInPrice = (-1).obs;
  final RxInt yesterdayChangeInPrice = 1.obs;

  final RxList<EventTransactionModel> eventList =
      RxList<EventTransactionModel>();

  void getDashboardMetrics() {
    _homePageRepository.getDashboardMetrics().then((value) {
      totalPrice.value = value.totalTransaction;
      todayPrice.value = value.todayTransaction;
      yesterdayPrice.value = value.yesterdayTransaction;
      todayChangeInPrice.value = value.todayChangeInTransaction;
      yesterdayChangeInPrice.value = value.yesterdayChangeInTransaction;
    });
  }

  void getEventMetrics() {
    _homePageRepository.getEventMetrics().then((value) {
      eventList.value = value;
    });
  }
}
