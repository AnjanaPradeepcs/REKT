import 'dart:async';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../app/utils/responsive.dart';
import '../../../../app/utils/typography.dart';
import 'home_page_controller.dart';

import '../../../../app/color.dart';
import 'widgets/summary_card.dart';

class HomePageView extends StatefulWidget {
  const HomePageView({super.key});

  @override
  State<HomePageView> createState() => _HomePageViewState();
}

class _HomePageViewState extends State<HomePageView> {
  late final HomePageController _homePageController =
      Get.put(HomePageController());

  @override
  void initState() {
    _homePageController.getDashboardMetrics();
    _homePageController.getEventMetrics();
    Timer.periodic(const Duration(seconds: 10), (timer) {
      _homePageController.getDashboardMetrics();
      _homePageController.getEventMetrics();
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
          padding: const EdgeInsets.symmetric(
            vertical: 44,
          ),
          color: AppColor.background,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              //PRICE SUMMARY
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Padding(
                  padding:
                      EdgeInsets.symmetric(horizontal: Responsive.width(67)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Obx(() => PriceSummaryCard(
                            price: _homePageController.totalPrice.value,
                            label: 'TOTAL',
                            changeInPrice: 0,
                          )),
                      SizedBox(width: Responsive.width(43)),
                      Obx(() => PriceSummaryCard(
                            price: _homePageController.todayPrice.value,
                            label: 'TODAY',
                            changeInPrice:
                                _homePageController.todayChangeInPrice.value,
                          )),
                      SizedBox(width: Responsive.width(43)),
                      Obx(() => PriceSummaryCard(
                            price: _homePageController.yesterdayPrice.value,
                            label: 'YESTERDAY',
                            changeInPrice: _homePageController
                                .yesterdayChangeInPrice.value,
                          )),
                    ],
                  ),
                ),
              ),
              SizedBox(height: Responsive.height(70)),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: Responsive.width(67)),
                child: Text(
                  'Events List',
                  style: fontStyle("white:600:22"),
                ),
              ),
              SizedBox(height: Responsive.height(41)),

              Padding(
                padding: EdgeInsets.symmetric(horizontal: Responsive.width(67)),
                child: Obx(() {
                  return Table(
                    children: [
                          TableRow(
                            children: [
                              Padding(
                                padding: EdgeInsets.only(
                                    bottom: Responsive.height(30), left: 20),
                                child: Center(
                                  child: Text(
                                    'Name',
                                    style: fontStyle("white:400:22"),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                    bottom: Responsive.height(30)),
                                child: Center(
                                  child: Text('Ticket Sold',
                                      style: fontStyle("white:400:22")),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                    bottom: Responsive.height(30)),
                                child: Center(
                                  child: Text('Total Transaction',
                                      style: fontStyle("white:400:22")),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                    bottom: Responsive.height(30)),
                                child: Center(
                                  child: Text('Convenience Fee Collected',
                                      style: fontStyle("white:400:22")),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                    bottom: Responsive.height(30)),
                                child: Center(
                                  child: Text('Event Date',
                                      style: fontStyle("white:400:22")),
                                ),
                              ),
                            ],
                          ),
                        ] +
                        _homePageController.eventList.map((e) {
                          final height = e.name.length > 16 ? 50 : 25;
                          return TableRow(children: [
                            Container(
                              margin: const EdgeInsets.only(bottom: 9),
                              padding: EdgeInsets.all(Responsive.width(24)),
                              color: AppColor.lightWhite.withOpacity(0.2),
                              child: SizedBox(
                                height: height.toDouble(),
                                child: Center(
                                  child: AutoSizeText(
                                    e.name,
                                    style: fontStyle("white:600:22"),
                                    minFontSize: 18,
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.only(bottom: 9),
                              padding: EdgeInsets.all(Responsive.width(24)),
                              color: AppColor.lightWhite.withOpacity(0.2),
                              child: SizedBox(
                                height: height.toDouble(),
                                child: Center(
                                  child: Text(
                                    e.ticketSold,
                                    style: fontStyle("white:600:22"),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.only(bottom: 9),
                              padding: EdgeInsets.all(Responsive.width(24)),
                              color: AppColor.lightWhite.withOpacity(0.2),
                              child: SizedBox(
                                height: height.toDouble(),
                                child: Center(
                                  child: Text(
                                    '\$${e.totalTransaction}',
                                    style: fontStyle("white:600:22"),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.only(bottom: 9),
                              padding: EdgeInsets.all(Responsive.width(24)),
                              color: AppColor.lightWhite.withOpacity(0.2),
                              child: SizedBox(
                                height: height.toDouble(),
                                child: Center(
                                  child: Text(
                                    e.convinceFee,
                                    style: fontStyle("white:600:22"),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.only(bottom: 9),
                              padding: EdgeInsets.all(Responsive.width(24)),
                              color: AppColor.lightWhite.withOpacity(0.2),
                              child: SizedBox(
                                height: height.toDouble(),
                                child: Center(
                                  child: Text(
                                    e.eventDate,
                                    style: fontStyle("white:600:22"),
                                  ),
                                ),
                              ),
                            ),
                          ]);
                        }).toList(),
                  );
                }),
              )
            ],
          )),
    );
  }
}
