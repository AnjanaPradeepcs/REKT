import 'package:flutter/material.dart';

import '../../../../../app/color.dart';
import '../../../../../app/utils/responsive.dart';
import '../../../../../app/utils/typography.dart';

class PriceSummaryCard extends StatelessWidget {
  const PriceSummaryCard({
    super.key,
    required this.price,
    required this.label,
    required this.changeInPrice,
  });
  final double price;
  final String label;
  final int changeInPrice;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        minWidth: Responsive.width(100),
      ),
      padding: EdgeInsets.symmetric(
        horizontal: Responsive.width(40),
        vertical: Responsive.height(27),
      ),
      decoration: BoxDecoration(
        color: AppColor.black,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                formatPrice(price),
                style: changeInPrice == 0
                    ? fontStyle("yellow:600:34")
                    : changeInPrice > 0
                        ? fontStyle("green:600:34")
                        : fontStyle("red:600:34"),
              ),
              const SizedBox(width: 20),
              changeInPrice > 0
                  ? Icon(
                      Icons.arrow_upward,
                      size: Responsive.width(24),
                      color: AppColor.green,
                    )
                  : changeInPrice < 0
                      ? Icon(
                          Icons.arrow_downward,
                          size: Responsive.width(24),
                          color: AppColor.red,
                        )
                      : const SizedBox(),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            label,
            style: fontStyle("white-0.6:600:22"),
          ),
        ],
      ),
    );
  }

  String formatPrice(double price) {
    final String formattedPrice = price.toStringAsFixed(3);
    final String formattedPriceWithComma = formattedPrice.replaceAllMapped(
        RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},');
    return '\$$formattedPriceWithComma';
  }
}
