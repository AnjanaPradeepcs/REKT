import 'package:flutter/foundation.dart';
import 'package:get/get.dart';

class TicketPageController extends GetxController {
  void searchTicket(String ticketId) {
    if (kDebugMode) {
      print("Searching for ticket with id: $ticketId");
    }
  }
}
