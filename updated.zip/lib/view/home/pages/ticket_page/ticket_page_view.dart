import 'package:flutter/material.dart';
import '../../../../app/utils/typography.dart';

import '../../../../app/utils/responsive.dart';

class TicketPageView extends StatelessWidget {
  TicketPageView({super.key});

  final TextEditingController _searchController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
          width: Responsive.width(626),
          padding: const EdgeInsets.symmetric(horizontal: 20),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.2),
            borderRadius: BorderRadius.circular(10),
          ),
          child: TextField(
            controller: _searchController,
            style: fontStyle("white:600:22"),
            decoration: InputDecoration(
              hintText: 'Search with Ticket ID',
              hintStyle: fontStyle("white-0.4:600:22"),
              border: InputBorder.none,
            ),
          )),
    );
  }
}
