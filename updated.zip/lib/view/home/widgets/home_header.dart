import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../app/color.dart';
import '../../../app/utils/responsive.dart';
import '../../../app/utils/typography.dart';
import '../home_screen_controller.dart';

class HomeHeader extends StatelessWidget {
  HomeHeader({super.key});
  final HomeScreenController homeScreenController =
      Get.find<HomeScreenController>();
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
          horizontal: Responsive.width(69), vertical: Responsive.height(30)),
      color: AppColor.black,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            padding: EdgeInsets.symmetric(
                horizontal: Responsive.width(24),
                vertical: Responsive.height(8)),
            width: Responsive.width(626),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: TextField(
              style: fontStyle("white:600:22"),
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: "Search...",
                hintStyle: fontStyle("white-0.4:600:22"),
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: Responsive.width(36),
                backgroundColor: AppColor.lightWhite,
                child: Icon(
                  Icons.person,
                  color: Colors.white,
                  size: Responsive.width(36),
                ),
              ),
              SizedBox(width: Responsive.width(28)),
              Obx(
                () => Text(
                  homeScreenController.username.value.toUpperCase(),
                  style: fontStyle("white:600:22"),
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}
