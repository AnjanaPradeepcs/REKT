import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../home_screen_controller.dart';
import '../../../app/color.dart';
import '../../../app/utils/responsive.dart';
import 'nav_tile.dart';

class NavDrawer extends StatelessWidget {
  const NavDrawer({
    super.key,
    required this.navItems,
  });

  final List<Map<String, AppPage>> navItems;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: double.infinity,
      padding: EdgeInsets.all(Responsive.width(40)),
      color: AppColor.black,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.asset(
            'assets/logo/logo_192.png',
            height: Responsive.height(96),
          ),
          SizedBox(height: Responsive.height(77)),
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: navItems.length,
            itemBuilder: (BuildContext context, int index) {
              return Obx(
                () => GestureDetector(
                  onTap: () {
                    Get.find<HomeScreenController>()
                        .navigateTo(navItems[index].values.first);
                  },
                  child: Container(
                    margin: EdgeInsets.only(bottom: Responsive.height(31)),
                    child: Center(
                      child: NavTile(
                        title: navItems[index].keys.first,
                        isSelected: navItems[index].values.first ==
                            Get.find<HomeScreenController>().selectedPage.value,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
