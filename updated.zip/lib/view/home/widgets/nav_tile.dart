import 'package:flutter/material.dart';

import '../../../app/utils/typography.dart';

class NavTile extends StatelessWidget {
  const NavTile({
    super.key,
    required this.title,
    required this.isSelected,
  });
  final String title;
  final bool isSelected;

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: isSelected
          ? fontStyle("white:600:22")
          : fontStyle("white-0.2:600:22"),
    );
  }
}
