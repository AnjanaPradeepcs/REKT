import 'package:get/get.dart';
import '../../data/repository/auth_repository.dart';

class LoginScreenController extends GetxController {
  final AuthRepository _authRepository = AuthRepository();
  final RxBool isLoading = false.obs;
  void login(String username, String password) {
    isLoading.value = true;
    _authRepository.login(username, password).then((value) {
      isLoading.value = false;
      if (value) {
        Get.offAllNamed('/home');
      }
    });
  }
}
