import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'login_screen_controller.dart';

import '../../app/utils/typography.dart';

class LoginScreenView extends StatefulWidget {
  const LoginScreenView({super.key});

  @override
  State<LoginScreenView> createState() => _LoginScreenViewState();
}

class _LoginScreenViewState extends State<LoginScreenView> {
  final LoginScreenController _loginScreenController =
      Get.put(LoginScreenController());
  final RxBool _obscureText = true.obs;
  final RxBool _isValidate = false.obs;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  void dispose() {
    Get.delete<LoginScreenController>();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SizedBox(
        width: double.infinity,
        child: Obx(
          () => Form(
            key: _formKey,
            autovalidateMode: _isValidate.value
                ? AutovalidateMode.always
                : AutovalidateMode.disabled,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Image.asset('assets/logo/logo.png', width: 300),
                const SizedBox(height: 20),
                Text(
                  'LOGIN',
                  style: fontStyle("white:300:20"),
                ),
                const SizedBox(height: 30),
                SizedBox(
                  width: 300,
                  child: TextFormField(
                    controller: _usernameController,
                    keyboardType: TextInputType.text,
                    validator: (String? value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter username';
                      }
                      return null;
                    },
                    style: fontStyle("white:400:16"),
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.2),
                      hintText: 'Username',
                      hintStyle: fontStyle("white-0.6:400:16"),
                      border: OutlineInputBorder(
                        borderSide: const BorderSide(color: Colors.white),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(color: Colors.white),
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: 300,
                  child: Obx(
                    () => TextFormField(
                      controller: _passwordController,
                      keyboardType: TextInputType.visiblePassword,
                      validator: (String? value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter password';
                        }
                        return null;
                      },
                      obscureText: _obscureText.value,
                      style: fontStyle("white:400:16"),
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Colors.white.withOpacity(0.2),
                        hintText: 'Password',
                        hintStyle: fontStyle("white-0.6:400:16"),
                        suffixIcon: InkWell(
                          onTap: () {
                            _obscureText.value = !_obscureText.value;
                          },
                          child: Icon(
                            _obscureText.value
                                ? Icons.visibility
                                : Icons.visibility_off,
                            size: 20,
                            color: Colors.grey[400],
                          ),
                        ),
                        border: OutlineInputBorder(
                          borderSide: const BorderSide(color: Colors.white),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(color: Colors.white),
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 30),
                InkWell(
                  borderRadius: BorderRadius.circular(40),
                  onTap: () {
                    if (_formKey.currentState!.validate()) {
                      _loginScreenController.login(
                          _usernameController.text, _passwordController.text);
                    } else {
                      _isValidate.value = true;
                    }
                  },
                  child: Container(
                    width: 300,
                    height: 48,
                    decoration: BoxDecoration(
                      color: Colors.blue[900],
                      borderRadius: BorderRadius.circular(40),
                    ),
                    child: Center(
                      child: Obx(
                        () {
                          if (_loginScreenController.isLoading.value) {
                            return const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                color: Colors.white,
                              ),
                            );
                          } else {
                            return Text(
                              'Sign In',
                              style: fontStyle("white:600:20"),
                            );
                          }
                        },
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
