import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../app/color.dart';
import '../../data/provider/preferences_manager.dart';

import '../../app/utils/responsive.dart';

class SplashScreenView extends StatefulWidget {
  const SplashScreenView({super.key});

  @override
  State<SplashScreenView> createState() => _SplashScreenViewState();
}

class _SplashScreenViewState extends State<SplashScreenView> {
  final PreferenceManager _preferenceManager = Get.find<PreferenceManager>();
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future.delayed(const Duration(seconds: 3), () {
        _preferenceManager.isLogin
            ? Get.offAllNamed('/home')
            : Get.offAllNamed('/login');
      });
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.background,
      body: Center(
        child: Image.asset(
          'assets/logo/logo.png',
          width: Responsive.width(586),
        ),
      ),
    );
  }
}
